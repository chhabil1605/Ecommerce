package com.ecommerce.seller_service.Request;

public class SellerRequest {

    private String gstNo;

    private String panCardNo;
}
