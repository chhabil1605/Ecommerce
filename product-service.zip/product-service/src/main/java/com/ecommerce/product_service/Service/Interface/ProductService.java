package com.ecommerce.product_service.Service.Interface;

import com.ecommerce.product_service.Request.AddProduct;
import com.ecommerce.product_service.Response.ProductSavedResponse;

public interface ProductService {
    public String addProduct(AddProduct addProduct);
}
