package com.ecommerce.product_service.Response;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class ProductSavedResponse {
    private String message;
}
