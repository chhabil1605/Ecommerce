package com.ecommerce.pdf_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
